from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.models import User
from django.template.loader import render_to_string
from django.db.models.query_utils import Q
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator
from django.utils.encoding import force_bytes
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .models import EmiData, Contact
from .forms import NewUserForm

# Create your views here.


def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            # print(user)
            login(request, user, backend="graphql_jwt.backends.JSONWebTokenBackend")
            messages.success(request, "Registration successful.")
            return redirect("homepage")
        messages.error(request, "Unsuccessful registration. Invalid information.")
    else:
        form = NewUserForm()
    return render(request, "loan/register.html", context={"register_form": form})


def login_request(request):
    thank = False
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            thank = True
            if user is not None:
                # user.backend = 'django.contrib.auth.backends.ModelBackend'
                login(request, user, backend="graphql_jwt.backends.JSONWebTokenBackend")
                messages.info(request, f"You are now logged in as {username}.")
                return redirect("homepage")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request, "loan/login.html", {"login_form": form, "thank": thank})


def logout_request(request):
    logout(request)
    messages.info(request, "You have successfully logged out.")
    return redirect("homepage")


def password_reset_request(request):
    if request.method == "POST":
        password_reset_form = PasswordResetForm(request.POST)
        if password_reset_form.is_valid():
            data = password_reset_form.cleaned_data["email"]
            associated_users = User.objects.filter(Q(email=data))
            if associated_users.exists():
                for user in associated_users:
                    subject = "Password Reset Requested"
                    email_template_name = "loan/password/password_reset_email.txt"
                    c = {
                        "email": user.email,
                        "domain": "127.0.0.1:8000",
                        "site_name": "Website",
                        "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                        "token": default_token_generator.make_token(user),
                        "protocol": "http",
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(
                            subject,
                            email,
                            "admin@example.com",
                            [user.email],
                            fail_silently=False,
                        )
                    except BadHeaderError:
                        return HttpResponse("Invalid header found.")

                    messages.success(
                        request,
                        "A message with reset password instructions has been sent to your inbox.",
                    )
                    return redirect("homepage")
            messages.error(request, "An invalid email has been entered.")
    password_reset_form = PasswordResetForm()
    return render(
        request,
        "loan/password/password_reset.html",
        context={"password_reset_form": password_reset_form},
    )


@login_required(login_url='/login/')
def homepage(request):
    return render(request, "loan/homepage.html")


@login_required(login_url='/login/')
def about(request):
    return render(request, "loan/about.html")


@login_required(login_url='/login/')
def news(request):
    return render(request, "loan/news.html")


@login_required(login_url='/login/')
def calculate(request):
    user = request.user
    if request.method == "POST":
        itemsJson = request.POST.get("itemsJson")
        tution_fee = request.POST.get("tution_fee")
        hostel_fee = request.POST.get("hostel_fee")
        material = request.POST.get("material")
        scholarship = request.POST.get("scholarship")
        contribution = request.POST.get("contribution")
        course_period = request.POST.get("course_period")
        interest_rate = request.POST.get("interest_rate")
        grace = request.POST.get("grace")
        tenure = request.POST.get("tenure")

        emi = EmiData(
            user = user,
            itemsJson=itemsJson,
            tution_fee=tution_fee,
            hostel_fee=hostel_fee,
            material=material,
            scholarship=scholarship,
            contribution=contribution,
            course_period=course_period,
            interest_rate=interest_rate,
            grace=grace,
            tenure=tenure,
        )
        emi.save()
        thank=True
        return render(request, "loan/calculate.html", {"thank": thank})
    return render(request, "loan/calculate.html")


@login_required(login_url='/login/')
def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        msg = request.POST.get('msg')
        contact = Contact(name=name, email=email, subject=subject, msg=msg)
        contact.save()
        thank = True
        return render(request, "loan/contact.html", {"thank":thank})
    return render(request, "loan/contact.html")


@login_required(login_url='/login/')
def how_to(request):
    return render(request, "loan/how_to.html")


@login_required(login_url='/login/')
def what_is(request):
    return render(request, "loan/what_is.html")


@login_required(login_url='/login/')
def benefits_of(request):
    return render(request, "loan/benefits_of.html")


@login_required(login_url='/login/')
def to_apply(request):
    return render(request, "loan/to_apply.html")


@login_required(login_url='/login/')
def results(request):
    return render(request, "loan/results.html")


@login_required(login_url='/login/')
def services(request):
    return render(request, "loan/services.html")
