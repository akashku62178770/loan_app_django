from django.contrib import admin
from .models import EmiData, Contact
# Register your models here.

admin.site.register(EmiData)
admin.site.register(Contact)