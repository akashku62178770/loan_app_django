from django.urls import path, include
from .views import *

# from google import views as view

urlpatterns = [
    path("", homepage, name="homepage"),
    path("register/", register_request, name="register"),
    path("login/", login_request, name="login"),
    path("logout/", logout_request, name="logout"),
    path("social-auth/", include("social_django.urls", namespace="social")),
    path("password_reset/", password_reset_request, name="password_reset"),
    path("about/", about, name="about"),
    path("calculate/", calculate, name="calculate"),
    path("results/", results, name="results"),
    path("contact/", contact, name="contact"),
    path("news/", news, name="news"),
    path("services/", services, name="services"),
    path("how_to/", how_to, name="how_to"),
    path("what_is/", what_is, name="what_is"),
    path("benefits_of/", benefits_of, name="benefits_of"),
    path("to_apply/", to_apply, name="to_apply"),
]
