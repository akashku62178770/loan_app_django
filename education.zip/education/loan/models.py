from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class EmiData(models.Model):
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE)
    itemsJson = models.CharField(max_length=5000, null=True, blank=True)
    tution_fee = models.IntegerField(default=0)
    hostel_fee = models.IntegerField(default=0)
    material = models.IntegerField(default=0)
    scholarship = models.IntegerField(default=0)
    contribution = models.IntegerField(default=0)
    course_period = models.IntegerField(default=0)
    interest_rate = models.IntegerField(default=0)
    grace = models.IntegerField(default=0)
    tenure = models.IntegerField(default=0)

    def __str__(self):
        return str(self.user)

class Contact(models.Model):
    name = models.CharField(max_length=50, blank=True)
    email = models.EmailField()
    subject = models.CharField(max_length=50, blank=True)
    msg = models.TextField(max_length=500)

    def __str__(self):
        return self.subject